#!/system/bin/sh

rm -rf /magisk/phh/xbin
mkdir -p /magisk/phh/xbin
cp -af /system/xbin/. /magisk/phh/xbin
rm -f /magisk/phh/xbin/su
ln -s /magisk/phh/su /magisk/phh/xbin/su

echo "#!/system/bin/sh" > /magisk/phh/xbin/supolicy
echo "LD_LIBRARY_PATH=/magisk/.core/bin /magisk/.core/bin/supolicy \"\$@\"" >> /magisk/phh/xbin/supolicy
echo " " >> /magisk/phh/xbin/supolicy
chmod 755 /magisk/phh/xbin/supolicy

cat /sys/fs/selinux/policy > /cache/sepolicy

# Live patch sepolicy for phh
/magisk/phh/sepolicy_patch.sh

rm /cache/sepolicy

setprop magisk.supath "/magisk/phh/xbin"
setprop magisk.phhsu 1
setprop magisk.root 1